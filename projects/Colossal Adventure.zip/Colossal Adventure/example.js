while(getRandomInt(1,3) === 3){
    
}